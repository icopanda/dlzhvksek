const auth = document.querySelector("#auth");
const game = document.querySelector("#game");
const nameInput = document.querySelector("#nameInput");
const joinBtn = document.querySelector("#joinBtn");
const startBtn = document.querySelector("#startBtn");
const leaveBtn = document.querySelector("#leaveBtn");
const statusTitle = document.querySelector("#statusTitle");
const myStats = document.querySelector("#myStats");
const myRoles = document.querySelector("#myRoles");
const players = document.querySelector("#players");
const turnBadge = document.querySelector("#turnBadge");
const targetSelect = document.querySelector("#targetSelect");
const actions = document.querySelector("#actions");
const authError = document.querySelector("#authError");
const actionError = document.querySelector("#actionError");
const logEl = document.querySelector("#log");

let state = null;
let playerId = localStorage.getItem("srcgPlayerId");
let code = localStorage.getItem("srcgCode");
let polling = null;

if (code && code !== "MAIN") {
  localStorage.removeItem("srcgCode");
  localStorage.removeItem("srcgPlayerId");
  code = null;
  playerId = null;
}

async function api(path, body) {
  const response = await fetch(path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || "요청에 실패했습니다.");
  return data;
}

function playerName() {
  return nameInput.value.trim() || "플레이어";
}

function saveSession(nextCode, nextPlayerId) {
  code = nextCode;
  playerId = nextPlayerId;
  localStorage.setItem("srcgCode", code);
  localStorage.setItem("srcgPlayerId", playerId);
}

function showGame(room, options = {}) {
  state = room;
  auth.classList.add("hidden");
  game.classList.remove("hidden");
  if (options.pushHistory && history.state?.view !== "game") {
    history.pushState({ view: "game" }, "", "/");
  }
  render();
  if (!polling) polling = setInterval(refresh, 900);
}

function showAuth() {
  state = null;
  code = null;
  playerId = null;
  localStorage.removeItem("srcgCode");
  localStorage.removeItem("srcgPlayerId");
  if (polling) {
    clearInterval(polling);
    polling = null;
  }
  actionError.textContent = "";
  authError.textContent = "";
  game.classList.add("hidden");
  auth.classList.remove("hidden");
}

function myPlayer() {
  return state?.players.find((player) => player.id === playerId);
}

function aliveTargets() {
  return state.players.filter((player) => player.alive && player.id !== playerId);
}

function render() {
  if (!state) return;
  const me = myPlayer();
  const current = state.players.find((player) => player.id === state.currentPlayerId);
  const winner = state.players.find((player) => player.id === state.winnerId);

  startBtn.classList.toggle("hidden", !(state.status === "lobby" && state.hostId === playerId));
  statusTitle.textContent =
    state.status === "lobby"
      ? "대기실"
      : state.status === "ended"
        ? `${winner?.name || "아무도"} 승리`
        : `${current?.name || ""}님의 차례`;
  turnBadge.textContent = state.status === "playing" ? (state.currentPlayerId === playerId ? "내 차례" : "대기 중") : "";

  myStats.innerHTML = `
    <div class="stat"><span>코인</span><strong>${me?.coins ?? 0}</strong></div>
    <div class="stat"><span>남은 직업</span><strong>${me?.roleCount ?? 0}</strong></div>
  `;
  myRoles.innerHTML = me?.roles?.length
    ? me.roles.map((role) => `<div class="role">${role}${role === "학생" ? " · 차례당 2코인" : ""}</div>`).join("")
    : `<div class="role">게임 시작 전</div>`;

  players.innerHTML = state.players
    .map((player) => {
      const tags = [
        `${player.coins}코인`,
        `직업 ${player.roleCount}개`,
        player.skipped ? "차례 넘김 예정" : "",
        player.id === state.hostId ? "방장" : "",
      ]
        .filter(Boolean)
        .map((tag) => `<span>${tag}</span>`)
        .join("");
      return `
        <article class="player ${player.id === state.currentPlayerId ? "current" : ""} ${player.alive ? "" : "dead"}">
          <div class="player-name">
            <span>${player.name}${player.id === playerId ? " (나)" : ""}</span>
            <span>${player.alive ? "생존" : "탈락"}</span>
          </div>
          <div class="player-meta">${tags}</div>
        </article>
      `;
    })
    .join("");

  targetSelect.innerHTML = aliveTargets().map((player) => `<option value="${player.id}">${player.name}</option>`).join("");
  renderActions(me);

  logEl.innerHTML = state.log
    .map((item) => `<div class="log-item"><strong>${item.at}</strong> ${item.message}</div>`)
    .join("");
}

function actionButton(label, type, needsTarget = false, disabled = false) {
  const target = needsTarget ? targetSelect.value : "";
  return `<button data-type="${type}" data-target="${target}" ${disabled ? "disabled" : ""}>${label}</button>`;
}

function renderActions(me) {
  const isTurn = state.status === "playing" && state.currentPlayerId === playerId && state.pendingAction && me?.alive;
  const canTarget = aliveTargets().length > 0;
  const roleSet = new Set(me?.roles || []);
  const buttons = [];

  buttons.push(actionButton("턴 넘기기", "pass", false, !isTurn));
  buttons.push(actionButton("5코인으로 직업 지우기", "erase", true, !isTurn || !canTarget || (me?.coins || 0) < 5));
  buttons.push(actionButton("대통령 · 직업 재배정", "대통령", false, !isTurn || !roleSet.has("대통령")));
  buttons.push(actionButton("법무관 · 대통령 차단", "법무관", false, !isTurn || !roleSet.has("법무관")));
  buttons.push(actionButton("경찰 · 직업 하나 확인", "경찰", true, !isTurn || !roleSet.has("경찰") || me?.usedPolice || !canTarget));
  buttons.push(actionButton("산업스파이 · 코인 1개 탈취", "산업스파이", true, !isTurn || !roleSet.has("산업스파이") || !canTarget));
  buttons.push(actionButton("군인 · 다음 차례 넘김", "군인", true, !isTurn || !roleSet.has("군인") || !canTarget));

  actions.innerHTML = buttons.join("");
}

async function refresh() {
  if (!code || !playerId) return;
  try {
    const data = await api("/api/state", { code, playerId });
    state = data.room;
    render();
  } catch {
    clearInterval(polling);
    polling = null;
  }
}

joinBtn.addEventListener("click", async () => {
  authError.textContent = "";
  try {
    const data = await api("/api/join", { name: playerName() });
    saveSession(data.room.code, data.playerId);
    showGame(data.room, { pushHistory: true });
  } catch (error) {
    authError.textContent = error.message;
  }
});

startBtn.addEventListener("click", async () => {
  actionError.textContent = "";
  try {
    const data = await api("/api/start", { code, playerId });
    showGame(data.room);
  } catch (error) {
    actionError.textContent = error.message;
  }
});

leaveBtn.addEventListener("click", () => {
  showAuth();
  if (history.state?.view === "game") {
    history.replaceState({ view: "auth" }, "", "/");
  }
});

targetSelect.addEventListener("change", render);

actions.addEventListener("click", async (event) => {
  const button = event.target.closest("button");
  if (!button) return;
  actionError.textContent = "";
  try {
    const data = await api("/api/action", {
      code,
      playerId,
      type: button.dataset.type,
      targetId: button.dataset.target || targetSelect.value,
    });
    showGame(data.room);
  } catch (error) {
    actionError.textContent = error.message;
  }
});

if (code && playerId) {
  refresh().then(() => {
    if (state) showGame(state, { pushHistory: true });
  });
}

window.addEventListener("popstate", () => {
  if (!auth.classList.contains("hidden")) return;
  showAuth();
});

if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("/sw.js").catch(() => {});
  });
}
